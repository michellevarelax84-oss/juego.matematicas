const pantallaJuego = document.getElementById("pantallaJuego");
const pantallaFinal = document.getElementById("pantallaFinal");

const btnComprobar = document.getElementById("btnComprobar");
const btnReiniciar = document.getElementById("btnReiniciar");

const tituloJuego = document.getElementById("tituloJuego");

const grupo1 = document.getElementById("grupo1");
const grupo2 = document.getElementById("grupo2");

const operacionFrutas = document.getElementById("operacionFrutas");
const operacionNumeros = document.getElementById("operacionNumeros");

const numero1 = document.getElementById("numero1");
const numero2 = document.getElementById("numero2");

const respuesta = document.getElementById("respuesta");
const mensaje = document.getElementById("mensaje");

const estrellasTexto = document.getElementById("estrellas");
const nivelTexto = document.getElementById("nivel");
const barra = document.getElementById("barra");
const resultado = document.getElementById("resultado");

const audioCorrecto = document.getElementById("audioCorrecto");
const audioError = document.getElementById("audioError");
const audioAplausos = document.getElementById("audioAplausos");

// Nuevos selectores del Modal y Barra de Obstáculos
const instructionModal = document.getElementById("instruction-modal");
const modalIcon = document.getElementById("modal-icon");
const modalTitle = document.getElementById("modal-title");
const modalDesc = document.getElementById("modal-desc");
const modalSpeakBtn = document.getElementById("modal-speak-btn");
const modalStartBtn = document.getElementById("modal-start-btn");

const gameplayText = document.getElementById("gameplay-text");
const gameplayIcon = document.getElementById("gameplay-icon");
const gameplaySpeakBtn = document.getElementById("gameplay-speak-btn");

let nivel = 1;
let estrellas = 0;

let n1 = 0;
let n2 = 0;
let correcta = 0;
let ecuacionesSesion = [];

let audioCtx = null;

function initAudio() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx && audioCtx.state === "suspended") {
        audioCtx.resume();
    }
}

/* ========================= */
/* VOZ (TEXT-TO-SPEECH) */
/* ========================= */

function hablar(texto) {
    speechSynthesis.cancel();

    const msg = new SpeechSynthesisUtterance(texto);
    msg.lang = "es-ES";
    msg.rate = 0.95;
    msg.pitch = 1.6;

    const voces = speechSynthesis.getVoices();
    const voz = voces.find(v =>
        v.name.includes("Helena") ||
        v.name.includes("Laura") ||
        v.name.includes("Paulina") ||
        v.name.includes("Sabina") ||
        v.name.includes("Female")
    );

    if (voz) {
        msg.voice = voz;
    }

    // Guardar referencia global para evitar que sea eliminado por el recolector de basura (GC Bug)
    window.currentUtterance = msg;

    speechSynthesis.speak(msg);
}

function aleatorio(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/* ========================= */
/* MEZCLA DE ECUACIONES */
/* ========================= */

function generarEcuacionesSesion() {
    const listaPosibles = [
        { a: 3, b: 2 },
        { a: 4, b: 3 },
        { a: 5, b: 1 },
        { a: 2, b: 6 },
        { a: 4, b: 5 },
        { a: 2, b: 2 },
        { a: 1, b: 2 },
        { a: 6, b: 3 },
        { a: 3, b: 5 },
        { a: 2, b: 4 },
        { a: 4, b: 1 },
        { a: 3, b: 1 },
        { a: 5, b: 2 },
        { a: 1, b: 6 },
        { a: 7, b: 2 },
        { a: 2, b: 5 }
    ];
    
    // Shuffle
    for (let i = listaPosibles.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = listaPosibles[i];
        listaPosibles[i] = listaPosibles[j];
        listaPosibles[j] = temp;
    }
    
    ecuacionesSesion = listaPosibles.slice(0, 4);
}

generarEcuacionesSesion();

/* ========================= */
/* BARRA Y PASOS DE PROGRESO (OBSTÁCULOS) */
/* ========================= */

function updateProgress(stepNumber) {
    const fillPercent = ((stepNumber - 1) / 3) * 100;
    const progressFill = document.getElementById("progress-fill");
    if (progressFill) progressFill.style.width = fillPercent + "%";
    
    for (let i = 1; i <= 4; i++) {
        const stepEl = document.getElementById("step-" + i);
        if (stepEl) {
            if (i < stepNumber) {
                stepEl.className = "progress-step completed";
            } else if (i === stepNumber) {
                stepEl.className = "progress-step active";
            } else {
                stepEl.className = "progress-step";
            }
        }
    }
}

/* ========================= */
/* CREAR FRUTAS PARA CONTEO */
/* ========================= */

function crearFrutas(contenedor, cantidad, emoji) {
    contenedor.innerHTML = "";

    for (let i = 1; i <= cantidad; i++) {
        const fruta = document.createElement("span");
        fruta.className = "objeto";
        fruta.textContent = emoji;

        fruta.addEventListener("click", () => {
            hablar(i);
        });

        contenedor.appendChild(fruta);
    }
}

/* ========================= */
/* CONFIGURACIONES DE OBSTÁCULOS */
/* ========================= */

const INFO_OBSTACULOS = {
    1: {
        titulo: "Obstáculo 1: Cuenta y Suma",
        desc: "Cuenta las manzanas y los plátanos en cada grupo. Luego, escribe el resultado total de la suma.",
        icon: "🍎",
        speakText: "Cuenta las manzanas y los plátanos en cada grupo. Luego, escribe el resultado total de la suma."
    },
    2: {
        titulo: "Obstáculo 2: Súper Suma",
        desc: "Cuenta las frutillas y las uvas en cada grupo. Luego, escribe el resultado total de la suma.",
        icon: "🍓",
        speakText: "Cuenta las frutillas y las uvas en cada grupo. Luego, escribe el resultado total de la suma."
    },
    3: {
        titulo: "Obstáculo 3: Suma Mental",
        desc: "Resuelve la suma de dos números mentalmente y escribe la respuesta correcta.",
        icon: "🧠",
        speakText: "Resuelve la suma de dos números mentalmente y escribe la respuesta correcta."
    },
    4: {
        titulo: "Obstáculo 4: Desafío Final",
        desc: "Resuelve esta suma mental de mayor dificultad para ganar el juego. ¡Tú puedes!",
        icon: "🏆",
        speakText: "Resuelve esta suma mental de mayor dificultad para ganar el juego. ¡Tú puedes!"
    }
};

/* ========================= */
/* ABRIR MODAL EXPLICACIÓN */
/* ========================= */

function abrirModalExplicacion() {
    initAudio();
    const info = INFO_OBSTACULOS[nivel];
    if (!info) return;

    modalIcon.textContent = info.icon;
    modalTitle.textContent = info.titulo;
    modalDesc.textContent = info.desc;
    
    gameplayIcon.textContent = info.icon;
    gameplayText.textContent = info.desc;

    // Restaurar botones y voz para el modo de juego
    const speakBtnInModal = document.getElementById("modal-speak-btn");
    if (speakBtnInModal) speakBtnInModal.style.display = "block";

    const buttonsContainer = document.querySelector(".modal-buttons-container");
    if (buttonsContainer) {
        buttonsContainer.innerHTML = `<button class="btn-action" id="modal-start-btn">Comenzar</button>`;
        const newStartBtn = document.getElementById("modal-start-btn");
        newStartBtn.onclick = () => {
            instructionModal.classList.add("hidden");
            speechSynthesis.cancel();
            initAudio();
        };
    }

    instructionModal.classList.remove("hidden");

    hablar(info.speakText);

    modalSpeakBtn.onclick = () => hablar(info.speakText);
    gameplaySpeakBtn.onclick = () => hablar(info.desc);
}

/* ========================= */
/* GENERAR NIVEL */
/* ========================= */

function generarNivel() {
    pantallaJuego.style.display = "block";
    mensaje.textContent = "";
    respuesta.value = "";
    updateProgress(nivel);

    const ec = ecuacionesSesion[nivel - 1];
    n1 = ec.a;
    n2 = ec.b;
    correcta = n1 + n2;

    if (nivel === 1) {
        tituloJuego.textContent = "🍎 Cuenta y Suma";
        operacionFrutas.style.display = "flex";
        operacionNumeros.style.display = "none";

        crearFrutas(grupo1, n1, "🍎");
        crearFrutas(grupo2, n2, "🍌");
        resultado.textContent = "= ?";
    }

    if (nivel === 2) {
        tituloJuego.textContent = "🍓 Súper Suma";
        operacionFrutas.style.display = "flex";
        operacionNumeros.style.display = "none";

        crearFrutas(grupo1, n1, "🍓");
        crearFrutas(grupo2, n2, "🍇");
        resultado.textContent = "= ?";
    }

    if (nivel === 3) {
        tituloJuego.textContent = "🧠 Suma Mental";
        operacionFrutas.style.display = "none";
        operacionNumeros.style.display = "flex";

        numero1.textContent = n1;
        numero2.textContent = n2;
        resultado.textContent = "= ?";
    }

    if (nivel === 4) {
        tituloJuego.textContent = "🏆 Desafío Final";
        operacionFrutas.style.display = "none";
        operacionNumeros.style.display = "flex";

        numero1.textContent = n1;
        numero2.textContent = n2;
        resultado.textContent = "= ?";
    }

    nivelTexto.textContent = nivel;
    abrirModalExplicacion();
}

/* EVENTOS */
numero1.addEventListener("click", () => hablar(n1));
numero2.addEventListener("click", () => hablar(n2));

btnComprobar.addEventListener("click", () => {
    initAudio();
    const valor = Number(respuesta.value);

    if (valor === correcta) {
        mensaje.textContent = "🎉 ¡Correcto!";
        mensaje.className = "correcto";

        estrellas++;
        estrellasTexto.textContent = estrellas;

        if (audioCorrecto) audioCorrecto.play();
        hablar("Muy bien");

        setTimeout(() => {
            nivel++;
            if (nivel > 4) {
                localStorage.setItem("actividad2", "completada");
                if (audioAplausos) audioAplausos.play();
                hablar("Felicitaciones. Has completado todas las sumas.");

                confetti({
                    particleCount: 250,
                    spread: 150,
                    origin: { y: 0.6 }
                });

                // Configurar Modal de Victoria
                modalIcon.textContent = "🏆🎉";
                modalTitle.textContent = "¡Felicidades, Campeón!";
                modalDesc.textContent = "Has completado con éxito los 4 obstáculos del mercado de las sumas.";
                
                const speakBtnInModal = document.getElementById("modal-speak-btn");
                if (speakBtnInModal) speakBtnInModal.style.display = "none";

                const buttonsContainer = document.querySelector(".modal-buttons-container");
                if (buttonsContainer) {
                    buttonsContainer.innerHTML = `
                        <button class="btn-action" onclick="window.location.href='basico4.html'" style="background: linear-gradient(135deg, #38bdf8, #0ea5e9); box-shadow: 0 6px 0 #0284c7, 0 10px 15px rgba(14, 165, 233, 0.25);">
                            🏠 Volver al Menú
                        </button>
                        <button class="btn-action" onclick="window.location.href='actividad3.html'">
                            ➡️ Siguiente Actividad
                        </button>
                    `;
                }

                instructionModal.classList.remove("hidden");
            } else {
                generarNivel();
            }
        }, 1200);
    } else {
        mensaje.textContent = "❌ Inténtalo otra vez";
        mensaje.className = "error";

        if (audioError) audioError.play();
        hablar("Intenta nuevamente");
    }
});

btnReiniciar.addEventListener("click", () => {
    nivel = 1;
    estrellas = 0;
    generarEcuacionesSesion();

    estrellasTexto.textContent = "0";
    nivelTexto.textContent = "1";

    pantallaFinal.style.display = "none";
    pantallaJuego.style.display = "block";

    hablar("Vamos a empezar otra vez");
    generarNivel();
});

window.onload = () => {
    document.body.addEventListener("click", () => {
        initAudio();
    }, { once: true });

    generarNivel();
};